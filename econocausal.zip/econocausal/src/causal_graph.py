"""
Week 1 / Mid-project review: define the causal DAG with DoWhy and run
refutation tests that prove the causal effect is isolated from confounders.

Roles in the graph:
  - Treatment (T): whether the customer received a discount / promo email
  - Outcome   (Y): conversion (or spend)
  - Confounders (W): variables that affect BOTH who gets treated and the
    outcome (e.g. `channel_web`, `newbie`, `recency`) — these are what a
    naive model would let leak into the effect estimate.
  - Effect modifiers (X): variables that make the treatment effect
    heterogeneous across users (e.g. `newbie`, `history`) — these define
    the "Persuadable" segments EconoCausal is built to find.
"""
import pandas as pd
from dowhy import CausalModel

TREATMENT = "treatment"
OUTCOME = "conversion"
CONFOUNDERS = ["recency", "channel_web", "newbie"]
EFFECT_MODIFIERS = ["newbie", "history", "channel_web"]

GML_GRAPH = """
graph [
  directed 1
  node [ id "recency" label "recency" ]
  node [ id "history" label "history" ]
  node [ id "channel_web" label "channel_web" ]
  node [ id "newbie" label "newbie" ]
  node [ id "zip_urban" label "zip_urban" ]
  node [ id "treatment" label "treatment" ]
  node [ id "conversion" label "conversion" ]

  edge [ source "recency" target "treatment" ]
  edge [ source "channel_web" target "treatment" ]
  edge [ source "newbie" target "treatment" ]

  edge [ source "recency" target "conversion" ]
  edge [ source "channel_web" target "conversion" ]
  edge [ source "newbie" target "conversion" ]
  edge [ source "history" target "conversion" ]
  edge [ source "zip_urban" target "conversion" ]

  edge [ source "treatment" target "conversion" ]
]
"""


def build_causal_model(df: pd.DataFrame) -> CausalModel:
    model = CausalModel(
        data=df,
        treatment=TREATMENT,
        outcome=OUTCOME,
        graph=GML_GRAPH.replace("\n", " "),
    )
    return model


def identify_and_estimate(df: pd.DataFrame):
    """Identify the estimand from the DAG, then estimate with a DML-style
    backdoor estimator (a lightweight DoWhy-native check that should agree,
    directionally, with the full EconML DML model in dml_model.py)."""
    model = build_causal_model(df)
    identified_estimand = model.identify_effect(proceed_when_unidentifiable=True)

    estimate = model.estimate_effect(
        identified_estimand,
        method_name="backdoor.econml.dml.LinearDML",
        method_params={
            "init_params": {
                "model_y": "auto",
                "model_t": "auto",
                "discrete_treatment": True,
            },
            "fit_params": {},
        },
    )
    return model, identified_estimand, estimate


def run_refutation_tests(model, identified_estimand, estimate):
    """
    Refutation tests try to BREAK the causal claim. If the estimated effect
    stays stable under each of these, that's the evidence the effect is
    genuinely causal and not an artifact of confounding or model choice.
    """
    results = {}

    # 1. Add a random common cause -> effect should barely change.
    results["random_common_cause"] = model.refute_estimate(
        identified_estimand, estimate, method_name="random_common_cause"
    )

    # 2. Replace treatment with a random (placebo) variable -> effect should
    #    collapse to ~0. If it doesn't, the model is picking up noise/leakage.
    results["placebo_treatment"] = model.refute_estimate(
        identified_estimand, estimate,
        method_name="placebo_treatment_refuter", placebo_type="permute",
    )

    # 3. Remove a random subset of the data -> effect should be stable.
    results["data_subset"] = model.refute_estimate(
        identified_estimand, estimate,
        method_name="data_subset_refuter", subset_fraction=0.8,
    )

    return results


if __name__ == "__main__":
    df = pd.read_csv("data/synthetic_campaign.csv")
    model, estimand, estimate = identify_and_estimate(df)
    print("Identified estimand:\n", estimand)
    print("\nEstimated ATE:", estimate.value)

    refutations = run_refutation_tests(model, estimand, estimate)
    for name, res in refutations.items():
        print(f"\n--- {name} ---\n{res}")
