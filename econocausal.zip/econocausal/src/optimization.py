"""
Week 3: Prescriptive Optimization.

Given each user's ITE at two candidate discount levels ($10, $20) and a
fixed total budget, solve for the discount allocation that maximizes total
*incremental* conversions (or revenue), not raw conversion probability.

Formulated as an LP relaxation of a knapsack problem:
    maximize   sum_i sum_d  ite[i, d] * value[i, d] * x[i, d]
    subject to sum_i sum_d  d * x[i, d]  <= budget
               sum_d x[i, d] <= 1                 (at most one discount per user)
               0 <= x[i, d] <= 1                   (LP relaxation; round after)
"""
import numpy as np
import pandas as pd
from scipy.optimize import linprog

DISCOUNT_LEVELS = (0, 10, 20)  # 0 = no discount (always a feasible option)


def build_allocation_problem(scored_df: pd.DataFrame, budget: float,
                              discount_levels=DISCOUNT_LEVELS,
                              avg_order_value: float = 45.0):
    """
    scored_df must have columns: ite_discount_10, ite_discount_20 (from
    dml_model.py). Returns the LP matrices for scipy.optimize.linprog.
    """
    n = len(scored_df)
    n_d = len(discount_levels)

    # Expected incremental revenue per (user, discount) cell.
    # linprog MINIMIZES, so we negate to maximize.
    value = np.zeros((n, n_d))
    for j, d in enumerate(discount_levels):
        if d == 0:
            value[:, j] = 0.0
        else:
            ite_col = f"ite_discount_{d}"
            value[:, j] = scored_df[ite_col].values * avg_order_value

    c = -value.flatten()  # objective coefficients (negated for min -> max)

    # Constraint 1: budget
    cost = np.zeros((n, n_d))
    for j, d in enumerate(discount_levels):
        cost[:, j] = d
    A_ub = [cost.flatten()]
    b_ub = [budget]

    # Constraint 2: at most one discount level chosen per user
    A_eq = np.zeros((n, n * n_d))
    for i in range(n):
        A_eq[i, i * n_d:(i + 1) * n_d] = 1
    b_eq = np.ones(n)

    bounds = [(0, 1)] * (n * n_d)
    return c, A_ub, b_ub, A_eq, b_eq, bounds, n, n_d


def solve_allocation(scored_df: pd.DataFrame, budget: float,
                      discount_levels=DISCOUNT_LEVELS,
                      avg_order_value: float = 45.0) -> pd.DataFrame:
    c, A_ub, b_ub, A_eq, b_eq, bounds, n, n_d = build_allocation_problem(
        scored_df, budget, discount_levels, avg_order_value
    )

    res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                   bounds=bounds, method="highs")
    if not res.success:
        raise RuntimeError(f"Optimizer failed: {res.message}")

    x = res.x.reshape(n, n_d)
    chosen_idx = x.argmax(axis=1)  # round LP relaxation to nearest discount
    chosen_discount = np.array(discount_levels)[chosen_idx]

    out = scored_df.copy()
    out["assigned_discount"] = chosen_discount
    out["expected_incremental_revenue"] = [
        out[f"ite_discount_{d}"].iloc[i] * avg_order_value if d > 0 else 0.0
        for i, d in enumerate(chosen_discount)
    ]
    out["spend_from_budget"] = chosen_discount
    return out.sort_values("expected_incremental_revenue", ascending=False)


def compare_to_blanket_targeting(allocation_df: pd.DataFrame,
                                  blanket_discount: float = 10.0,
                                  avg_order_value: float = 45.0) -> dict:
    """
    Produces the natural-language ROI summary from the spec, e.g.
    "This strategy saves $4,200 compared to blanket targeting."
    """
    optimized_spend = allocation_df["spend_from_budget"].sum()
    optimized_revenue = allocation_df["expected_incremental_revenue"].sum()

    n = len(allocation_df)
    blanket_spend = blanket_discount * n
    blanket_revenue = (allocation_df["ite_discount_10"] * avg_order_value).sum() \
        if blanket_discount == 10 else (allocation_df["ite_discount_20"] * avg_order_value).sum()

    return {
        "optimized_spend": round(optimized_spend, 2),
        "optimized_incremental_revenue": round(optimized_revenue, 2),
        "blanket_spend": round(blanket_spend, 2),
        "blanket_incremental_revenue": round(blanket_revenue, 2),
        "budget_saved": round(blanket_spend - optimized_spend, 2),
        "revenue_gain": round(optimized_revenue - blanket_revenue, 2),
        "summary": (
            f"Optimized targeting spends ${optimized_spend:,.0f} "
            f"(vs ${blanket_spend:,.0f} blanket) and captures "
            f"${optimized_revenue:,.0f} incremental revenue "
            f"(vs ${blanket_revenue:,.0f} blanket) — a saving of "
            f"${blanket_spend - optimized_spend:,.0f} for "
            f"${optimized_revenue - blanket_revenue:,.0f} more revenue."
        ),
    }


if __name__ == "__main__":
    scored = pd.read_csv("data/ite_scores.csv")
    allocation = solve_allocation(scored, budget=5000)
    allocation.to_csv("data/allocation.csv", index=False)
    print(compare_to_blanket_targeting(allocation)["summary"])
    print(f"\nSaved final prescription -> data/allocation.csv ({len(allocation)} rows)")
