"""
Week 2: train the EconML Double/Debiased Machine Learning model and estimate
the Individual Treatment Effect (ITE) for every user.

Double ML works by residualizing out the confounders in TWO stages
(hence "double"):
  1. Model outcome Y ~ confounders W  ->  get residual Y_res
  2. Model treatment T ~ confounders W  ->  get residual T_res
  3. Regress Y_res on T_res (optionally interacted with effect modifiers X)
This removes the correlation between confounders and treatment assignment,
isolating the *causal* signal from the *correlational* noise a plain
classifier would pick up.

We use CausalForestDML so the treatment effect can vary per user (needed for
"how much does THIS user's probability change if given $10 vs $20") — a plain
LinearDML would only give one constant coefficient per segment.
"""
import numpy as np
import pandas as pd
from econml.dml import CausalForestDML, LinearDML
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor

CONFOUNDERS = ["recency", "channel_web", "newbie", "zip_urban"]
EFFECT_MODIFIERS = ["newbie", "history", "channel_web"]
OUTCOME_COL = "conversion"
TREATMENT_COL = "treatment"


def train_dml(df: pd.DataFrame,
              confounders=CONFOUNDERS,
              effect_modifiers=EFFECT_MODIFIERS,
              outcome_col=OUTCOME_COL,
              treatment_col=TREATMENT_COL) -> CausalForestDML:
    """Train a Causal Forest DML model that outputs a per-user ITE."""
    Y = df[outcome_col].values
    T = df[treatment_col].values
    W = df[confounders].values          # confounders (nuisance-only)
    X = df[effect_modifiers].values     # effect modifiers (heterogeneity)

    est = CausalForestDML(
        model_y=GradientBoostingRegressor(n_estimators=100, max_depth=3),
        model_t=GradientBoostingClassifier(n_estimators=100, max_depth=3),
        discrete_treatment=True,
        n_estimators=500,
        min_samples_leaf=20,
        random_state=42,
    )
    est.fit(Y, T, X=X, W=W)
    return est


def estimate_dose_response(est: CausalForestDML, df: pd.DataFrame,
                            effect_modifiers=EFFECT_MODIFIERS,
                            discount_levels=(10, 20)) -> pd.DataFrame:
    """
    Produce the ITE for each user, i.e. how much their conversion
    probability increases under each discount level. CausalForestDML gives
    the effect of moving treatment 0->1; we scale it by discount size as a
    simple dose-response approximation (swap in a continuous-treatment DML
    estimator for a fully non-linear dose-response curve).
    """
    X = df[effect_modifiers].values
    base_ite = est.effect(X)  # effect of "any discount" vs none

    out = df.copy()
    out["ite_base"] = base_ite
    for d in discount_levels:
        # naive linear dose scaling for illustration; replace with
        # est.effect(X, T0=0, T1=d) if you fit a continuous-treatment DML
        out[f"ite_discount_{d}"] = base_ite * (d / max(discount_levels))

    # 90% confidence interval per user, for the dashboard's uncertainty bands
    lb, ub = est.effect_interval(X, alpha=0.1)
    out["ite_ci_lower"] = lb
    out["ite_ci_upper"] = ub

    out["segment"] = classify_segment(out["ite_base"], threshold=0.02)
    return out


def classify_segment(ite: pd.Series, threshold: float = 0.02) -> pd.Series:
    """
    Bucket users into the four causal-marketing segments using the ITE sign
    and magnitude (Sure Things / Lost Causes / Persuadables / Sleeping Dogs
    require baseline P(buy|untreated) too — this is the simplified,
    ITE-only view used for prioritization).
    """
    return pd.cut(
        ite,
        bins=[-np.inf, -threshold, threshold, np.inf],
        labels=["Sleeping Dog", "Low Impact", "Persuadable"],
    )


if __name__ == "__main__":
    df = pd.read_csv("data/synthetic_campaign.csv")
    est = train_dml(df)
    scored = estimate_dose_response(est, df)
    scored.to_csv("data/ite_scores.csv", index=False)
    print(scored[["ite_base", "ite_ci_lower", "ite_ci_upper", "segment"]].describe(include="all"))
    print(f"\nSaved per-user ITE scores -> data/ite_scores.csv ({len(scored)} rows)")
