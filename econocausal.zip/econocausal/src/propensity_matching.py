"""
Propensity Score Matching (PSM): balances the observational (non-randomized)
historical campaign data so treated and untreated users look statistically
alike on their confounders — simulating a randomized A/B test after the fact.

Used two ways in this project:
  1. As a standalone sanity-check estimator (ATE via matching) to compare
     against the EconML DML estimate.
  2. As a nuisance model (propensity score) that feeds into DML's own
     debiasing step in dml_model.py.
"""
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import NearestNeighbors


def estimate_propensity_scores(df: pd.DataFrame, covariates: list[str],
                                treatment_col: str = "treatment") -> np.ndarray:
    """Fit P(treatment=1 | covariates) with logistic regression."""
    clf = LogisticRegression(max_iter=1000)
    clf.fit(df[covariates], df[treatment_col])
    return clf.predict_proba(df[covariates])[:, 1]


def match_on_propensity(df: pd.DataFrame, covariates: list[str],
                         treatment_col: str = "treatment",
                         caliper: float = 0.03) -> pd.DataFrame:
    """
    1-to-1 nearest-neighbor matching on the propensity score.
    Returns a matched dataframe (subset of df) with balanced treatment groups.
    """
    df = df.copy()
    df["propensity"] = estimate_propensity_scores(df, covariates, treatment_col)

    treated = df[df[treatment_col] == 1]
    control = df[df[treatment_col] == 0]

    nn = NearestNeighbors(n_neighbors=1)
    nn.fit(control[["propensity"]])
    distances, indices = nn.kneighbors(treated[["propensity"]])

    keep_mask = distances.flatten() <= caliper
    matched_control = control.iloc[indices.flatten()[keep_mask]]
    matched_treated = treated.iloc[keep_mask]

    matched = pd.concat([matched_treated, matched_control]).reset_index(drop=True)
    return matched


def att_via_matching(df: pd.DataFrame, covariates: list[str],
                      outcome_col: str = "conversion",
                      treatment_col: str = "treatment") -> float:
    """Average Treatment effect on the Treated (ATT), estimated via matching.
    Used as a quick cross-check against the DML ATE in dml_model.py."""
    matched = match_on_propensity(df, covariates, treatment_col)
    att = (
        matched.loc[matched[treatment_col] == 1, outcome_col].mean()
        - matched.loc[matched[treatment_col] == 0, outcome_col].mean()
    )
    return att


def check_covariate_balance(df: pd.DataFrame, covariates: list[str],
                             treatment_col: str = "treatment") -> pd.DataFrame:
    """Standardized mean difference before matching — values > 0.1 flag an
    imbalanced (confounded) covariate that DML needs to correct for."""
    treated = df[df[treatment_col] == 1]
    control = df[df[treatment_col] == 0]
    rows = []
    for c in covariates:
        pooled_std = np.sqrt((treated[c].var() + control[c].var()) / 2)
        smd = (treated[c].mean() - control[c].mean()) / (pooled_std + 1e-9)
        rows.append({"covariate": c, "standardized_mean_diff": smd})
    return pd.DataFrame(rows)


if __name__ == "__main__":
    df = pd.read_csv("data/synthetic_campaign.csv")
    covariates = ["recency", "history", "channel_web", "newbie", "zip_urban"]

    print("Covariate balance BEFORE matching:")
    print(check_covariate_balance(df, covariates))

    att = att_via_matching(df, covariates)
    print(f"\nATT via propensity matching: {att:.4f}")
