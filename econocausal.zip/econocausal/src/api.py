"""
Week 4: wrap the causal engine in a REST API, plus a simple data-drift
detector (Population Stability Index) that warns when incoming customer
data no longer resembles the data the DML model was trained on.

Run:
    uvicorn src.api:app --reload
Then open http://localhost:8000/docs for interactive API docs.
"""
import os
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from src.optimization import solve_allocation, compare_to_blanket_targeting

app = FastAPI(title="EconoCausal API", version="1.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")


class AllocationRequest(BaseModel):
    budget: float = 5000.0
    avg_order_value: float = 45.0


class ITEResponse(BaseModel):
    user_id: int
    ite_base: float
    ite_ci_lower: float
    ite_ci_upper: float
    segment: str


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/ite", response_model=list[ITEResponse])
def get_ite_scores(limit: int = 100):
    """Return per-user ITE scores (from the pre-trained DML model, see
    src/dml_model.py to regenerate data/ite_scores.csv)."""
    path = os.path.join(DATA_DIR, "ite_scores.csv")
    if not os.path.exists(path):
        raise HTTPException(404, "ite_scores.csv not found — run src/dml_model.py first")
    df = pd.read_csv(path).reset_index().rename(columns={"index": "user_id"})
    return df[["user_id", "ite_base", "ite_ci_lower", "ite_ci_upper", "segment"]] \
        .head(limit).to_dict(orient="records")


@app.post("/allocate")
def allocate_budget(req: AllocationRequest):
    """Run the SciPy optimizer over the current ITE scores and return the
    final prescription table + the ROI summary vs. blanket targeting."""
    path = os.path.join(DATA_DIR, "ite_scores.csv")
    if not os.path.exists(path):
        raise HTTPException(404, "ite_scores.csv not found — run src/dml_model.py first")
    scored = pd.read_csv(path)

    allocation = solve_allocation(scored, budget=req.budget,
                                   avg_order_value=req.avg_order_value)
    summary = compare_to_blanket_targeting(allocation, avg_order_value=req.avg_order_value)

    return {
        "summary": summary,
        "allocation_preview": allocation.head(50).to_dict(orient="records"),
        "total_users_allocated": int((allocation["assigned_discount"] > 0).sum()),
    }


@app.get("/uplift-curve")
def uplift_curve():
    """Data for the Qini / uplift chart in dashboard/index.html: cumulative
    incremental conversions captured vs. % of population targeted, sorted by
    ITE, compared against random targeting."""
    path = os.path.join(DATA_DIR, "ite_scores.csv")
    if not os.path.exists(path):
        raise HTTPException(404, "ite_scores.csv not found — run src/dml_model.py first")
    df = pd.read_csv(path).sort_values("ite_base", ascending=False).reset_index(drop=True)

    n = len(df)
    pct_targeted = np.linspace(0.01, 1.0, 50)
    model_curve, random_curve = [], []
    cum_ite = df["ite_base"].cumsum()
    total_ite = df["ite_base"].sum()

    for p in pct_targeted:
        k = max(1, int(p * n))
        model_curve.append(float(cum_ite.iloc[k - 1]))
        random_curve.append(float(total_ite * p))

    return {
        "pct_targeted": pct_targeted.tolist(),
        "model_cumulative_uplift": model_curve,
        "random_cumulative_uplift": random_curve,
    }


def population_stability_index(expected: pd.Series, actual: pd.Series, bins: int = 10) -> float:
    """
    PSI < 0.1  -> no significant drift
    0.1 - 0.25 -> moderate drift, monitor
    > 0.25     -> significant drift, retrain the DML model
    """
    breakpoints = np.quantile(expected, np.linspace(0, 1, bins + 1))
    breakpoints[0], breakpoints[-1] = -np.inf, np.inf

    expected_pct = pd.cut(expected, breakpoints).value_counts(normalize=True).sort_index()
    actual_pct = pd.cut(actual, breakpoints).value_counts(normalize=True).sort_index()

    eps = 1e-4
    psi = ((actual_pct + eps - (expected_pct + eps)) * np.log((actual_pct + eps) / (expected_pct + eps))).sum()
    return float(psi)


@app.post("/drift-check")
def drift_check():
    """Compare the covariate distribution the model was trained on against
    the most recent batch of scored users; flags if a retrain is needed."""
    train_path = os.path.join(DATA_DIR, "synthetic_campaign.csv")
    scored_path = os.path.join(DATA_DIR, "ite_scores.csv")
    if not (os.path.exists(train_path) and os.path.exists(scored_path)):
        raise HTTPException(404, "Run download_data.py and dml_model.py first")

    train_df = pd.read_csv(train_path)
    recent_df = pd.read_csv(scored_path)

    results = {}
    for col in ["recency", "history", "channel_web", "newbie"]:
        if col in train_df.columns and col in recent_df.columns:
            psi = population_stability_index(train_df[col], recent_df[col])
            results[col] = {
                "psi": round(psi, 4),
                "status": "OK" if psi < 0.1 else "MONITOR" if psi < 0.25 else "RETRAIN_NEEDED",
            }
    return results
