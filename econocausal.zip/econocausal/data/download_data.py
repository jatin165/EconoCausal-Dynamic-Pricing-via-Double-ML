"""
Download (or simulate) the historical campaign dataset used by EconoCausal.

Primary source: Kevin Hillstrom's MineThatData E-Mail Analytics dataset —
a genuine 3-arm randomized email experiment (Men's email / Women's email /
No email) over 64,000 customers. This is the standard public benchmark for
uplift / causal marketing models.

    http://www.minethatdata.com/Kevin_Hillstrom_MineThatData_E-MailAnalytics_DataMiningChallenge_2008.03.20.csv

If the direct download is unreachable (e.g. offline dev), we fall back to a
synthetic generator with a KNOWN ground-truth treatment effect, so the rest
of the pipeline (DML, refutation tests, optimizer) can still be developed
and unit-tested without a network connection.

Usage:
    python data/download_data.py
"""
import os
import sys
import numpy as np
import pandas as pd

HILLSTROM_URL = (
    "http://www.minethatdata.com/"
    "Kevin_Hillstrom_MineThatData_E-MailAnalytics_DataMiningChallenge_2008.03.20.csv"
)
OUT_PATH = os.path.join(os.path.dirname(__file__), "hillstrom.csv")


def download_hillstrom(out_path: str = OUT_PATH) -> pd.DataFrame:
    """Download the real Hillstrom dataset and standardize column names."""
    import requests
    from io import StringIO

    resp = requests.get(HILLSTROM_URL, timeout=30)
    resp.raise_for_status()
    df = pd.read_csv(StringIO(resp.text))

    # Standardize to the schema the rest of the pipeline expects.
    # Original columns: recency, history_segment, history, mens, womens,
    # zip_code, newbie, channel, segment, visit, conversion, spend
    df = df.rename(columns={"segment": "treatment_raw"})
    # Binary treatment for the causal pipeline: any promotional email vs none.
    # (You can instead run the pipeline per-arm to compare Men's vs Women's.)
    df["treatment"] = (df["treatment_raw"] != "No E-Mail").astype(int)
    df["discount_amount"] = np.where(
        df["treatment_raw"] == "Womens E-Mail", 20,
        np.where(df["treatment_raw"] == "Mens E-Mail", 10, 0),
    )
    df.to_csv(out_path, index=False)
    print(f"Saved real Hillstrom dataset -> {out_path} ({len(df)} rows)")
    return df


def simulate_campaign_data(n: int = 20_000, seed: int = 42) -> pd.DataFrame:
    """
    Synthetic fallback with a KNOWN ground-truth Individual Treatment Effect,
    so you can validate that the DML pipeline recovers the true effect before
    trusting it on real observational data.
    """
    rng = np.random.default_rng(seed)

    recency = rng.integers(1, 12, n)                     # months since last purchase
    history = rng.gamma(2.0, 50.0, n)                    # $ spent historically
    channel_web = rng.integers(0, 2, n)
    newbie = rng.integers(0, 2, n)
    zip_urban = rng.integers(0, 2, n)

    X = np.column_stack([recency, history, channel_web, newbie, zip_urban])

    # Propensity depends on confounders -> NOT a randomized experiment,
    # so a naive model would be confounded (this is what DML must correct for).
    propensity = 1 / (1 + np.exp(-(0.4 * channel_web - 0.03 * recency + 0.3 * newbie)))
    treatment = rng.binomial(1, propensity)
    discount_amount = np.where(treatment == 1, rng.choice([10, 20], n), 0)

    # True heterogeneous treatment effect (ground truth, for validation only):
    # persuadables = newbie web-shoppers with low recent history.
    true_ite = (
        0.18 * newbie
        + 0.10 * channel_web
        - 0.01 * history / 100
        + 0.002 * discount_amount
    )
    true_ite = np.clip(true_ite, 0, None)

    base_conversion = 0.05 + 0.02 * np.log1p(history) / 10 - 0.01 * recency / 12
    conversion_prob = np.clip(base_conversion + treatment * true_ite, 0, 1)
    conversion = rng.binomial(1, conversion_prob)
    spend = conversion * rng.gamma(2.0, 25.0, n)

    df = pd.DataFrame({
        "recency": recency,
        "history": history,
        "channel_web": channel_web,
        "newbie": newbie,
        "zip_urban": zip_urban,
        "treatment": treatment,
        "discount_amount": discount_amount,
        "conversion": conversion,
        "spend": spend,
        "true_ite": true_ite,  # ground truth — drop before training, keep for validation
    })
    df.to_csv(os.path.join(os.path.dirname(__file__), "synthetic_campaign.csv"), index=False)
    print(f"Saved synthetic fallback dataset -> data/synthetic_campaign.csv ({n} rows)")
    return df


if __name__ == "__main__":
    try:
        download_hillstrom()
    except Exception as e:
        print(f"Could not download the real dataset ({e}). Falling back to synthetic data.",
              file=sys.stderr)
        simulate_campaign_data()
